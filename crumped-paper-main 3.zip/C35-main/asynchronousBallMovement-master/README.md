# asynchronousBallMovement
Boiler plate for ball moving aysnchronously
